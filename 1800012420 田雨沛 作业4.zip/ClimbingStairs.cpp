﻿// ClimbingStairs.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>
#include "util.h"
#include "fun.h"

using namespace std;

int main()
{
	Initialize();
	return 0;
}
